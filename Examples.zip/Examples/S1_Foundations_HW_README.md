# Final_Repo


## Homework: Nested Loops


### Overall Task:

Students are creating a multiplication table given two random numbers and printing the table in a table format. Then using the same values to create three new versions of the first table, flipped horizontally, flipped vertically and then flipped both horizontally and vertically.

### Task 1: `get_nums():`

In `get_nums()` function use python module "random" to generate two random numbers: 

  1. Use `random.rantint(<start>,<end–inclusive>)`to generate 2 numbers between 3 and 12 (inclusive) 
  2. Return generated numbers to main as `num_1` and `num_2`

### Task 2: `print_table(num_1,num_2):`

Use returned numbers 1 and 2 to construct nested for loops that print a multiplication table of the two numbers.

  1. Create a nested loop that will print out a multiplication table of the range 1-num_1 and 1-num_2
      1. Create a loop for num_1 that prints all numbers from 1-num_1(inclusive)
      2. Create another loop for num_2 that prints all numbers from 1-num_2
      3. Nest the second loop inside the first loop 
      4. add code inside inner loop to print number in `range(1-num_1)` multiplied by number in `range(1-num_2)`
  2. Make sure to format the table so that each number takes up the same amount of space 
  3. Print table 
      1. Your print out should look like this: 
      ``` 
          1   2   3   4   5   6   7   8   9  10  11  12 
          2   4   6   8  10  12  14  16  18  20  22  24 
          3   6   9  12  15  18  21  24  27  30  33  36 
          4   8  12  16  20  24  28  32  36  40  44  48 
          5  10  15  20  25  30  35  40  45  50  55  60 
          6  12  18  24  30  36  42  48  54  60  66  72 
      ```
  4. Print a line of dashes, asterisks or alike after the table (student’s choice as long as it stays consistent)

### Task 3: `print_flpd_tables(num_1,num_2):`

Use the code generated in task 2 to create three new versions of this table:

  1. Manipulate the range values in 3 new blocks of code to create the same table:
      1. Print the table flipped horizontally (1 should be on the bottom left, like the example below):
      ```
          6  12  18  24  30  36  42  48  54  60  66  72 
          5  10  15  20  25  30  35  40  45  50  55  60 
          4   8  12  16  20  24  28  32  36  40  44  48 
          3   6   9  12  15  18  21  24  27  30  33  36 
          2   4   6   8  10  12  14  16  18  20  22  24 
          1   2   3   4   5   6   7   8   9  10  11  12 
      ```
      2. Print the table flipped vertically (1 should be on the top right, like the example below):
      ```
           12  11  10   9   8   7   6   5   4   3   2   1 
           24  22  20  18  16  14  12  10   8   6   4   2 
           36  33  30  27  24  21  18  15  12   9   6   3 
           48  44  40  36  32  28  24  20  16  12   8   4 
           60  55  50  45  40  35  30  25  20  15  10   5 
           72  66  60  54  48  42  36  30  24  18  12   6  
      ``` 
      3. Print the table flipped both horizontally and vertically (1 should be on the bottom right, like the example below):
      ```
           72  66  60  54  48  42  36  30  24  18  12   6 
           60  55  50  45  40  35  30  25  20  15  10   5 
           48  44  40  36  32  28  24  20  16  12   8   4 
           36  33  30  27  24  21  18  15  12   9   6   3 
           24  22  20  18  16  14  12  10   8   6   4   2 
           12  11  10   9   8   7   6   5   4   3   2   1 
      ```

  2. Ensure that each table contains all the same printed values as before, just in a different order
  3. Print a line of dashes, asterisks or alike between each printed table 

### Task 4: 

Construct a main that calls each function in the correct order (1,2,3), saves the required returns, and inputs the required arguments:

  1. Call `get_nums` and assign the returned values to two variables called num_1 and num_2 
  2. Call `print_table` using num_1 and num_2 as inputs
  3. Call `print_flpd_tables` using num_1 and num_2 as inputs 
