#DO NOT EDIT THIS FUNCTION. LEAVE AS IS
def word_checker(secret_word, guessed_letters):
    """Checks the secret word against the guessed letters from player2 and makes sure they are correct."""
    for letter in secret_word:
        if letter not in guessed_letters:
            return False
    return True

#OBJECTIVE ONE: CREATE A FUNCTION THAT TAKES INPUT FROM THE USER AND CHECKS IT AGAINST THE GIVEN SET OF PARAMETERS.
#TIPS: USER INPUT MUST BE ONE WORD, NO NUMBERS OR SYMBOLS ALLOWED, LOWERCASE LETTERS ONLY
def player1():
    """Input your docstring here."""
    pass
    
def player2(secret_word):
#OBJECTIVE TWO: CREATE A FUNCTION THAT ASKS THE SECOND USER FOR A LETTER.
#WHEN THE LETTER IS IN THE SECRET WORD, IT IS ADDED TO THE DISPLAY
#WHEN THE LETTER IS NOT IN THE SECRET WORD, THE USER GETS A STRIKE
    """Input your docstring here."""
    guessed_letters = ("a", "b", "c") #THIS LINE MUST BE REMOVED. HERE AS PLACEHOLDER ONLY.
    return guessed_letters #THIS LINE MUST BE REMOVED. HERE AS PLACEHOLDER ONLY.
            
    #DO NOT EDIT THIS PART OF THE FUNCTION. LEAVE AS IS
    if word_checker(secret_word, guessed_letters):
        win(secret_word)
    else:
        print("Oh wait you can't try again because you lost! Better luck next time :(")
        
def win(secret_word):
#OBJECTIVE THREE: DESIGN THE CONGRAGULATORY WIN PRINTER
#THIS FUNCTION SHOULD ONLY BE CALLED WHEN THE GAME IS WON
    """Input your docstring here."""
    pass
    
#DO NOT EDIT ANY OF THE BELOW CODE. LEAVE AS IS    
def main():
    """Calls the above functions to activate the game."""
    print("Let's play hangman!")
    secret_word = player1()
    player2(secret_word)
    print("The End")
    
if __name__ == "__main__":
    main()
    