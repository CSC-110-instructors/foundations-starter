import random
#DO NOT MODIFY ABOVE THIS LINE:
#_______________________________________


def get_nums(): #no input, 2 int outputs
    """ Uses the python module random to generate two numbers, returns two ints

    two variables are created and assigned to the generated numbers
    numbers between 3 and 12 are generated using the random module
    these numbers are then returned to main """
    num_1 = random.randint(3,12) #end range is inclusive 
    num_2 = random.randint(3,12)
    return num_1, num_2

def print_table(num_1,num_2): #2 inputs (ints), no outputs
    """ Uses two int inputs in nested loops to print a multiplcation table

    uses num_1 + 1 as end range in outer loop
    uses num_2 +1 as end range in inner loop
    prints the result of row times col without a new line
    prints a new line for each row
    then prints a line of astriks"""
    for row in range(1, num_1+1):
        for col in range(1, num_2+1):
            print(f"{row*col:3d}", end=" ") #formats the number with 3 spaces and doesn't print a new line
        print() #prints new line for new row 
    print("*" *45) #prints line separating printouts
    
def print_flpd_tables(num_1,num_2): #2 inputs (ints), no outputs
    """ Uses two int inputs in nested loops to print three altered version of orginal table

    uses num_1 as start range in outer loop, going backawards by one
    uses num_2 + 1 as end range in inner loop
    prints the result of row times col without a new line
    prints a newline for each row
    prints a line of astriks
    repeats above process once with just col range altered to go backwards from num_2
    and once with both ranges altered to go backwards from num_1 and num_2, respectively"""
    for row in range(num_1,0,-1): #going from num_1- 1 by subtracting 1 each time
        for col in range(1,num_2+1): #unchanged from before
            print(f"{row*col:3d}", end=" ") #formats the number with 3 spaces and doesn't print a new line
        print() #prints new line for new row
    print("*" *45) #prints line separating printouts
    for row in range(1,num_1+1): #unchanged from first table
        for col in range(num_2,0, -1): #going from num_2- 1 by subtracting 1 each time
            print(f"{row*col:3d}", end=" ") #formats the number with 3 spaces and doesn't print a new line
        print() #prints new line for new row
    print("*" *45) #prints line separating printouts
    for row in range(num_1,0, -1):# both ranges altered  
        for col in range(num_2,0, -1): 
            print(f"{row*col:3d}", end=" ") #formats the number with 3 spaces and doesn't print a new line
        print() #prints new line for new row
        
def main():
    """ calls above functions with inputs

    saves returned numbers from get_nums
    calls print_table with inputs of num_1 and num_2
    calls print_flpd_tables with inputs of num_1 and num_2"""
    num_1,num_2= get_nums() # saves the returned numbers as variables
    print_table(num_1,num_2)
    print_flpd_tables(num_1,num_2)
    
#DO NOT MOTIFY ANYTHING BELOW THIS LINE:
#_______________________________________
if __name__ == "__main__":
    main()