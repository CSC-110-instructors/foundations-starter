def word_checker(secret_word, guessed_letters):
    """Checks the secret word against the guessed letters from player2 and makes sure they are correct."""
    #this function was not part of my original plan, but I think it's the easiest way to make playyer2 do what I want it to. Give to students?
    for letter in secret_word:
        if letter not in guessed_letters:
            return False
            #if any letter in the secret word is not guessed by the time the game ends, this conditional will return as false
    return True
    #if all the letters in the secret word have been guessed, this conditional returns true
        
def player1():
    """Has the user input a word. If the word is invalid, an error message appears."""
    secret_word = input("Player One: Enter a word for the other player to guess: ")
    #asks the user to input a word for the hangman game
    switch = True
    #acts as an on/off switch for the if statements
    while switch == True:
    #while the switch is set to true, these things will happen
        if secret_word.isalpha():
        #if the secret word contains only alphabetical characters, the next clause is investigated
            if secret_word.islower():
            #if the letters in the secret word are all lowercase, the switch is flipped and the while loop endsprint("test")
                print("\033[H\033[J", end="")
                #this command clears the terminal once all if conditions are met. does not work in the Thonny interpreter, but does well in the terminal.
                switch = False
            else:
            #if some of the letters are uppercase, an error message is printed and the loop restarts
                print("Error: Uppercase letters detected. Please try again.")
                secret_word = input("Player One: Enter a word for the other player to guess: ")
        else:
            #if there are non-aplhabetical characters detected in the user input, an error message is printed and the while loop restarts
            print("Error: Input is not entirely alphabetical. Remove any spaces, numbers, or symbols and try again.")
            secret_word = input("Player One: Enter a word for the other player to guess: ")
    
    print("Yay! Satisfactory Word! Screen now cleared for Player 2.")
    #print statement affirms to the user that the word is valid since the terminal is cleared
    return secret_word
    #once a satisfactory word is input, that word is returned to main
    
def player2(secret_word):
    """Has another user guess the word letter by letter. If they guess a incorrect symbol more than five times, the game ends. If they guess the word correctly, win is called."""
    guessed_letters = list()
    #creates a holding place for all of the letters that have already been guessed
    strikes_left = 5
    #how many chances the user has left to guess a correct letter
    
    while strikes_left > 0 and not word_checker(secret_word, guessed_letters):
    #creates a loop such that the guessing continues until either the user is out of strikes or the word is guessed
        display = ""
        #an empty string for letters and underscores to be added to to create a display for the secret word
        for letter in secret_word:
            if letter in guessed_letters:
                display += letter + " "
                #if a letter in the word has already been guessed, it will show up in the display in the correct spot
            else:
                display += "_ "
                #if a given letter in the secret word has not been guessed, its place will be held with an underscore
        if len(guessed_letters) == 0:
            print("Guessed Letters: ")
            #this fixes the formatting so that "set()" is not printed when no letters have been guessed
        else:
            print(f"Guessed Letters: {guessed_letters}")
            #normal print function for the guessed letters
        print(f"{strikes_left} strikes left")
        #shows how many strikes the user has left
        print(display)
        #prints the display built above
        letter_guess = input("Player 2 - Guess a Letter: ")
        #asks the user to input a letter
        if len(letter_guess) != 1:
               print("Invalid input. Please try again.")
               continue
                #if the user tries to guess more than one letter, an error message is printed and the rest of the function is ignored.
        if letter_guess in guessed_letters:
            print("You already guessed this letter. Please try again.")
            continue
            #if the user tries to guess a letter twice, an error message is printed and the rest of the loop is ignored
        guessed_letters.append(letter_guess)
        #adds the guessed letter to the set of other letters that have already been guessed
        if letter_guess in secret_word:
            print(f"The letter {letter_guess} is in the word!")
            #if the letter is in the secret word, this fact is confirmed via this printout
        else:
            strikes_left -= 1
            #if the user makes a wrong guess, the strike counter is augmented and an error message is printed
            print("Incorrrect. Please try again.")
            
    #the part below was not part of the original plan. Give to students already built and ask them not to modify
    if word_checker(secret_word, guessed_letters):
        #calls the word_checker function once all strikes have been exhausted
        win(secret_word)
        #calls the win function to activate the fun prize
    else:
        print("Oh wait you can't try again because you lost! Better luck next time :(")
        #displays a less fun message when the player loses
            
        
        
def win(secret_word):
    """A congragulatory printer that formats the secret_word fancy once it is guessed in player2."""
    print(f"Congratulations! You won! The word was *{secret_word}*!")
    #a congragulatory message for Player 2 after winning hangman. Tells them what the word was.
    for letter in secret_word:
        #for each letter in the word, it will be printed one by one and surrounded by stars
       print(f"***{letter}***")
    
def main():
    """Calls the above functions to activate the game."""
    print("Let's play hangman!")
    #starts the game off in a festive way
    secret_word = player1()
    #sets the return variable from the player1 function in a vriable that can be used in main
    player2(secret_word)
    #calls the player2 function with the secret_word argument derrived from the player1 function
    print("The End")
    #signifies the end of the game
    
if __name__ == "__main__":
    main()
    