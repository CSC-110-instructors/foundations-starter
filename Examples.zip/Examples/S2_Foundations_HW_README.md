# Homework 1: Loops

This homework asks students to build a multi-player "Hangman" style game. There are three functions students are expected to build: player1, player2, and win. If done correctly, this code should allow one user to input a secret word abd the second user is asked to guess what that word is one letter at a time. If the second user guesses a letter correctly, they learn where in the word that letter is. If they guess incorrectly, they get a strike. The second user must complete the word with less than five strikes to win the game and activate the "win" function, which prints a congragulatory message. If they are unsuccessful, a "Game Over" message is printed.

## Learning Obectives: 

This homework asks students to build different functions that use both "for" and "while" loops. Based on the instructions, students should be able to recognize that the player1 and player2 functions work best with a "while" loop and the win function works best with a "for" loop. Students will also have the opprotunity to use these loops to solve the logical problems associated with building a word-input function and a letter-guesser function.

## Instructions:

At this point, you should be familiar with building a function that takes user inputs. This homework asks you to build two functions that take user inputs and uses the two to create a multi-player "Hangman" style game.

There are three main tasks associated with this assignment:

1. Make the player1 function with input checking for the secret word
2. Make the player2 function with input checking for the guessed letter
	   1. You will also be asked to check the letter against the secret word to make sure if it is in the word or not
3. Make the win function to print a congragulatory message when the second player wins the letter guessing game

Here is an example of an expected printout:

Part One: 

```
Let's play hangman!
Player One: Enter a word for the other player to guess: hi hi 
Error: Input is not entirely alphabetical. Remove any spaces, numbers, or symbols and try again.
Player One: Enter a word for the other player to guess: Hello
Error: Uppercase letters detected. Please try again.
Player One: Enter a word for the other player to guess: hello
```

Part Two:
```
Yay! Satisfactory Word! Screen now cleared for Player 2.
Guessed Letters: 
5 strikes left
_ _ _ _ _ 
Player 2 - Guess a Letter: h
The letter h is in the word!
Guessed Letters: ['h']
5 strikes left
h _ _ _ _ 
Player 2 - Guess a Letter: w
Incorrrect. Please try again.
Guessed Letters: ['h', 'w']
4 strikes left
h _ _ _ _ 
Player 2 - Guess a Letter: l
The letter l is in the word!
Guessed Letters: ['h', 'w', 'l']
4 strikes left
h _ l l _ 
Player 2 - Guess a Letter: o
The letter o is in the word!
Guessed Letters: ['h', 'w', 'l', 'o']
4 strikes left
h _ l l o 
Player 2 - Guess a Letter: e
The letter e is in the word!
Congratulations! You won! The word was * hello *!
*** h ***
*** e ***
*** l ***
*** l ***
*** o ***
The End
```

Please not that you will not be asked to call any functions in this homework. The main is provided, as is the section of player2 that calls both win and word_checker (which itself is given to you as well).

You will be expected to add comments and docstrings to all of the functions you build.

### def word_checker(secret_word, guessed letter):

This function is the only one given to you aside from main. It is called in player2 and makes sure that all the letters in the secret word have been guessed before the win function is activated. Pay attention to the variables used in this function and if you change any names, make sure to check that this part of the file still works correctly. This should not be an issue if you are using the variables outlined in the instructions. 

### Task One: player1
This function asks one user to input a word and then checks it against a given set of conditions. If all the conditions are met, the loop ends and the screen is cleared for the next player. If the conditions are not met, the function continues until the user inputs a satisfactory word.

The steps to complete this function are detailed below:

  1. Remove the pass keyword
   2. Use the input keyword to ask the user for a word using the following prompt: Player One: Enter a word for the other player to guess:
   3. Check to see if the input is only letters. If it is not, print an error message with: Error: Input is not entirely alphabetical. Remove any spaces, numbers, or symbols and try again.
   4. Check to see if the letters are all lower case. If there is not, print an error message with: Error: Uppercase letters detected. Please try again.
   5. When a satisfactory word is input, enter this command to clear the screen: print("\033[H\033[J", end="")
        1. NOTE: This code will function correctly in the terminal but will not ptovide the desired results in the Thonny interpreter
   6. Once the screen has been cleared, print the message "Yay! Satisfactory Word! Screen now cleared for Player 2."
   7. Return the word the user input so that it can be used by the other functions.

### Task Two: player2

This function gives the second user the length of the word the first user input in player1 via a visual display. They are then asked to guess the word one letter at a time. If the letter guessed is in the word, it will show up in the display in its correct place. If the letter is not in the word, the user gets a strike. The user has five chances to get the letters in the word correct. If they are successful, the win function is activated.

The steps to complete this function are detailed below: 

  1.  Delete the placeholder guessed_letters list and the placeholder return function.
   2. Create an empty list for the guessed letters to be added to
   3. Create a strike counter starting at 5. This will be decreased under the necessary conditions. 
   4. Create a loop that functions when the strike counter is above 0 and "not word_checker(secret_word, guessed_letters)"
		1. The second half of this instruction should be added to your code exactly as it is written here.
   5. In this loop, create another loop to act as the display. 
		1. This loop should work on all the letters in the secret word
		2. If the letter has been guessed, it should be shown in the display. Use the format "letter " so that the display is not cramped
		3. If the letter has not been guessed, it should be displayed as an underscore. Use the format "_ " so the display is not cramped.
		4. It may be helpful for you to build this loop outside of the greater loop and then add it in after. However, it must be in the loop so it will be updated as more letters are guessed. 
   6. If no letters have been guessed, print "Guessed Letters: ". If letters have been guessed, they should be printed with the format "Guessed Letters: {guessed_letters}"
   7. Print the strikes left using the format: {strikes_left} strikes left
   8. Print the display you made in step 4
   9. Have the user input a letter with the input command "Player 2 - Guess a Letter: "
   10. If the user tries to input more than one letter, print the error message: Invalid input. Please try again.
		1. If this occurs, the rest of the function should be ignored
   11. If the user tries to input a letter they have already inputted, print the error message: You already guessed this letter. Please try again.
		1. If this occurs, the rest of the function should be ignored
   12. If a valid letter is input, append it to the set of guessed letters
   13. If the letter is in the word, print the message: The letter {letter_guess} is in the word!
   14. If the letter is not in the word, subtract one from the strike counter and print the message: Incorrrect. Please try again.

	The rest of the function will be given to you. Do not edit it.

### Task Three: win
This function is only called if the secret word is gussed in the player2 function. This function congragulates the player on winning the game of Hangman and then prints each letter in the word one by one and surrounded by starts.

The steps to complete this function are detailed below: 

  1. Remove the pass keyword
   2. Print the message: Congratulations! You won! The word was * {secret_word} * !
   3. Create a loop that operates on each letter in the secret word
   4. Each letter in the word should be printed on its own line and surrounded by three stars on either side of it. Here is what this printout should look like: *** {letter}***

## Tips: 

  1. The command str.isalpha() can be used to check if a string is comprised of only letters. Anything that is not a letter (including spaces) present in this string will prompt it to read false. 
   2. The command str.islower() can be used to check if a string is comprised of only lowercase letters
   3. The length of a set can be used to determine how many things are in it
   4. The command list.append(argument) can be used to add an element to a list.
   5. The format "x" * number can be used to make whatever is in the quotation marks print however many times you desire

## Notes on creation:

  1. The file fw_final_hw_example.py is a fully completed version of the homework. This is not the only way to complete the exercise, just the way that I would do it if I was asked to complete this homework myself.
   2. The file fw_final_hw_skeleton.py is the skeleton version of the homework that students would see if this was a real homework they were expected to submit.
