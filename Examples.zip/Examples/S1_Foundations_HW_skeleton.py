import random


#DO NOT MODIFY ABOVE THIS LINE:
#_______________________________________

def get_nums(): #no input, 2 int outputs
    """ Add Your DocString Here """
    
    #TODO: Add you own code here
    pass


def print_table(x,y): #2 inputs (ints), no outputs
    """ Add Your DocString Here """
    
    #TODO: Add you own code here
    pass  
    
        
def print_flpd_tables(x,y): #2 inputs (ints), no outputs
    """ Add Your DocString Here """
    
    #TODO: Add you own code here
    pass


def main():
    """ Add Your DocString Here """
    
    #TODO: Add you own code here
 
 
#DO NOT MOTIFY ANYTHING BELOW THIS LINE:
#_______________________________________
    
    
if __name__ == "__main__":
    main()